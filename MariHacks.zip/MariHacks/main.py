
import streamlit as st
import math
import random

from PIL import Image

image = Image.open("IMG_5607.JPG")
st.image(image, caption='Map of lovers')
st.text("Ignore the Error, just click on the checkboxes")


def dist(a, b):
    return math.sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)

def SA(cities, temperature = 1000000, cooling_rate = 0.003):
    current_path = random.sample(cities, len(cities))
    current_dist = sum(dist(current_path[i], current_path[(i+1)%len(current_path)]) for i in range(len(current_path)))
    while temperature > 1:
        new_path = current_path.copy()

        index1, index2 = random.sample(range(len(cities)), 2)

        new_path[index1], new_path[index2] = new_path[index2], new_path[index1]

        new_dist = sum(dist(new_path[i], new_path[(i+1) % len(new_path)]) for i in range(len(new_path)))

        if new_dist < current_dist or math.exp((current_dist - new_dist) / temperature) > random.uniform(0, 1):
            current_path = new_path
            current_dist = new_dist

        temperature *= 1 - cooling_rate

    return current_path, current_dist

pos = [
    (225, 567),
    (225, 567), (420, 163), (956, 180), (610, 453), (1050, 468)
]


Cities = []

Choice = [False, False, False, False, False, False]
Choice[1] = st.checkbox("Place 1", value=False, key=None, help=None, on_change=None)
Choice[2] = st.checkbox("Place 2", value=False, key=None, help=None, on_change=None)
Choice[3] = st.checkbox("Place 3", value=False, key=None, help=None, on_change=None)
Choice[4] = st.checkbox("Place 4", value=False, key=None, help=None, on_change=None)
Choice[5] = st.checkbox("Place 5", value=False, key=None, help=None, on_change=None)


for i in range(1, 6):
    if Choice[i] is True:
        Cities.append(pos[i])


path, distance = SA(Cities)
st.text("The Optimal Distance is ")
st.text(distance)
st.text("Unit: Px")
st.text("The Optimal Path is")

for i in range(len(path)):
    for j in range(1, 6):
        if pos[j] is path[i]:
            st.text(j)





